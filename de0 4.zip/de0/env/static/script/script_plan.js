function registerAccount() {
    alert('Funcionalidad para registrar cuenta aún no implementada.');
}

function createDiet() {
    alert('Funcionalidad para crear dieta aún no implementada.');
}

function searchFood() {
    alert('Funcionalidad para buscar comida o receta aún no implementada.');
}

function addFood(meal) {
    alert(`Agregar comida a ${meal}`);
}